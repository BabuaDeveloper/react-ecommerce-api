<?php

return [
    xPhpLib('bmFtZQ==') => xPhpLib('SW5zdGFsbA=='),
    xPhpLib('Y29uZmlndXJhdGlvbg==') => [
        xPhpLib('dmVyc2lvbg==') => [
            xPhpLib('UEhQID49IDguMQ==') => xPhpLib('OC4x'),
        ],
        xPhpLib('ZXh0ZW5zaW9ucw==') => [
            xPhpLib('QmNtYXRo'),
            xPhpLib('Q3R5cGU='),
            xPhpLib('ZmlsZWluZm8='),
            xPhpLib('SlNPTg=='),
            xPhpLib('TWJzdHJpbmc='),
            xPhpLib('T3BlbnNzbA=='),
            xPhpLib('UGRv'),
            xPhpLib('VG9rZW5pemVy'),
            xPhpLib('WG1s'),
        ],
    ],
    xPhpLib('d3JpdGFibGVz') => [
        xPhpLib('c3RvcmFnZQ=='),
        xPhpLib('Ym9vdHN0cmFwL2NhY2hl'),
    ],
    xPhpLib('bWlncmF0aW9u') => xPhpLib('X21pZ1ppcC54bWw='),
    xPhpLib('a2V5') => '',
    xPhpLib('ZG9tYWlu') => '',
    xPhpLib('YXBw') => [
        xPhpLib('QVBQX05BTUU=') => xPhpLib('Q2hhdGxvb3A='),
        xPhpLib('QVBQX0VOVg==') => '',
        xPhpLib('QVBQX0RFQlVH') => xPhpLib('dHJ1ZQ=='),
        xPhpLib('QVBQX1VSTA==') => xPhpLib('aHR0cDovLzEyNy4wLjAuMTo4MDAw'),
    ],
    xPhpLib('aW5zdGFsbGF0aW9u') => xPhpLib('aW5zdGFsbGF0aW9uLmpzb24='),
    xPhpLib('bG9jYWxob3N0X3VybA==') => [
        xPhpLib('bG9jYWxob3N0'),
        xPhpLib('MTI3LjAuMC4x'),
        xPhpLib('Wzo6MV0='),
        xPhpLib('bG9jYWxob3N0OjgwMDA=') ,
        xPhpLib('MTI3LjAuMC4xOjgwMDA='),
        xPhpLib('Wzo6MV06ODAwMA=='),
    ]
];
