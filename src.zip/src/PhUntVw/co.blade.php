@extends(xPhpLib('c3R2OjpzdG1z'))
@section('title', xPhpLib('SW5zdGFsbGF0aW9uIENvbXBsZXRlZA=='))
@section(xPhpLib('Y29udGVudA=='))
    @phXml('PGRpdiBjbGFzcz0id2l6YXJkLXN0ZXAtNCBkLWJsb2NrIj4NCiAgICAgICAgPGRpdiBjbGFzcz0iaW5zdGFsbC1jb21wbGV0ZSI+DQogICAgICAgICAgICA8aSBkYXRhLWZlYXRoZXI9ImNoZWNrLWNpcmNsZSI+PC9pPg0KICAgICAgICAgICAgPGgzPkluc3RhbGxlZCBzdWNjZXNzZnVsbHk8L2gzPg0KICAgICAgICA8L2Rpdj4=')
    @phXml('PGRpdiBjbGFzcz0icm93IGdvdG8tc2VsZWN0aW9uIj4NCiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImNvbC1zbS02Ij4=')
@endsection
